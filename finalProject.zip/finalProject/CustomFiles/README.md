# Connect4NeuralNetworkCuda
A neural network made to play the game of Connect 4. Compares the different speeds between using python (with both normal and vectorized) versus CUDA integration.
