
Necessary Libaries:
numpy
PySimpleGui
matplotlib



Files to run:
	main - This can be run to play connect 4

	neuralNetTrainingPython - This can be run to train a network

	run_pybind.py - Run to do test on CUDA


In run_pybind11.py, make sure to change the directory such to get the CUDA files.


If the build doesn't work. All the files are independelty grouped at "/finalProject/CustomFiles"
		